## List

<ul data-tabs class="tabs">
	<li><a data-tab href="#taba">Superheroes</a></li>
	<li><a data-tab href="#tabb">Ice Cream</a></li>
	<li><a data-tab href="#tabc">Seasons</a></li>
</ul>

<div data-tabs-content>
	<div data-tabs-pane class="tabs-pane active" id="taba">
		<p><strong>Superheros</strong></p>
		<p>Spiderman, Batman, or Iron Man... which one is your favorite?</p>
	</div>
	<div data-tabs-pane class="tabs-pane" id="tabb">
		<p><strong>Ice Cream</strong></p>
		<p>Chocolate, vanilla or strawberry?</p>
	</div>
	<div data-tabs-pane class="tabs-pane" id="tabc">
		<p><strong>Seasons</strong></p>
		<p>Winter, summer, spring or fall?</p>
	</div>
</div>


## Unstructured

<div data-tabs class="tabs">
	<p>
		<span><a data-tab href="#tab1">Superheroes</a></span>
		<span><a data-tab href="#tab2">Ice Cream</a></span>
		<span><a data-tab href="#tab3">Seasons</a></span>
	</p>
</div>

<div data-tabs-content>
	<div data-tabs-pane class="tabs-pane active" id="tab1">
		<p><strong>Superheros</strong></p>
		<p>Spiderman, Batman, or Iron Man... which one is your favorite?</p>
	</div>
	<div data-tabs-pane class="tabs-pane" id="tab2">
		<p><strong>Ice Cream</strong></p>
		<p>Chocolate, vanilla or strawberry?</p>
	</div>
	<div data-tabs-pane class="tabs-pane" id="tab3">
		<p><strong>Seasons</strong></p>
		<p>Winter, summer, spring or fall?</p>
	</div>
</div>